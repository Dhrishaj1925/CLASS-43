var ghost, ghostrunning;
var edges;




function preload() {
  ghostrunning=loadAnimation("ghost1.png","ghost2.png","ghost3.png");
}

function setup(){
createCanvas(400,400);
ghost=createSprite(180,190,10,20);
ghost.addAnimation("ghostmoving",ghostrunning);
  ghost.scale=0.4;
  edges=createEdgeSprites();
}

function draw(){
  background("black");
  ghost.bounceOff(edges);
  
  if(keyDown(LEFT_ARROW)){
    ghost.velocityX=-5;
  }
  if(keyDown(RIGHT_ARROW)){
    ghost.velocityX=5;
  }
  
drawSprites();

  
}